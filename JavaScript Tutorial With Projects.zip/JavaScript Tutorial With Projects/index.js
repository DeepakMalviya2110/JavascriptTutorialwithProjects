//1. Ways to print in Javascript
// console.log("Hello World");  // to write on console
//  alert("me");
//  document.write("this is document write");  //to write on page

// //2. Javascript Console API
// console.log("Hello World" + (4 + 6) + "Another one");  // to write on console
// console.warn("This is warning");
// console.error("This is an error"); 


//3. Javascript Variables
// What are Variables?  -> Containers to store data values
var number1 = 34;
var number2 = 56;
//console.log(number1 + number2);


// 4. Data Types in Javascript

//Numbers
var num1 = 455;
var num2 = 56.76;

//String
var str1 = "This is a string";
var str2 = 'This is also a string';

//Objects
var marks = {
    ravi: 34,
    shubham: 78,
    harry: 99.977
}

//Booleans

var a = true;
var b = false;

//console.log(a,b);

//var und=undefined;
var und;
//console.log(und);

var n = null;
//console.log(n);

//At a very high level, There are two types of datatypes in Javascript
// 1. Primitive Data Types: undefined, null, number,strings,boolean, symbol 
// 2. Reference Data Types: Arrays and Objects


var arr = [1, 2, "deepak", 4, 5];
//console.log(arr);

var a = 100;
var b = 10;

/* console.log("The value of a+b is ", a+b);
console.log("The value of a*b is ", a*b);
console.log("The value of a-b is ", a-b);
console.log("The value of a/b is ", a/b);

//Assignment Operators

var c=b;
//c+=2;
//c*=2;
//c-=2;
//c/=2;
console.log(c);
 */


//Comparision Operators
/* var x=56;
var y=67;

console.log(x==y);
console.log(x>y);
console.log(x<y);

//Logical Operators
//Logical AND, Logical OR, Logical NOT
console.log(true&&true);
console.log(true&&false);
console.log(false&&false);
console.log(false&&true);
 */

//Operators('+','-' etc) and Operands (Numbers)


//Functions in Javascript
//DRY: Do not repeat yourself
function avg(a, b) {
    return (a + b) / 2;
}

c1 = avg(4, 6);
c2 = avg(14, 20);

//console.log(c1+" "+c2);

//color of number in console: blue
//color of string in console: black

// Conditionals in Javascript
//If else is same as Java
/* age=34;
if(age>18)
{
    console.log("you are can drink rasna water");
}
else{
    console.log("you cannot drink rasna water");
}
 */

//Loops in Javascript
/*
var arr=[1,2,"Deepak", 4, 100,5];
for(var i=0;i<arr.length;i++)
{
    console.log(arr[i]);  //break,continue is also there same as java
} */

// arr.forEach(function(element){
//     console.log(element);
// });


//const a=0;  //const can't be redefined
// a++;// it will throw error

// let j=0;
// while(j<arr.length)
// {
//     console.log(arr[j]);
//     j++;
// }

// do while is also there same as Java


//  let myArr=["Fan","Camera",34,null]; // array is heterogenous, can be anything unlike java
// // //Array.length
// // console.log(myArr.length);   //length of array
// // myArr.pop();      //remove last element
// // myArr.push("Deepak");   //add another element at last
// // myArr.shift();           //remove first element
// // console.log(myArr);      
// // const mylen=myArr.unshift("Hi");  //add element at first
// // console.log(mylen);
// // console.log(myArr);

// // console.log(myArr.toString());
// // myArr.sort();   
// // console.log(myArr);

// // let arr2=[4,2,1,7,9,14,11];
// // arr2.sort();         //It sort on the basis of the way it will come in dictionary 1,111,2,232,33 as it convert it into strings
// // console.log(arr2);



// //String Methods in Javascript
// let myString="Harry is a good good good boy";
// console.log(myString.length);  //length of string
// console.log(myString.indexOf("good"));  //returns first index of appearance
// console.log(myString.lastIndexOf("good"));  //returns last index of appearance
// console.log(myString.slice(3,10));   //same as substring of java, it takes starting index+number of chars

// console.log(myString.replace("Harry","Deepak"));  //replace the word Harry by Deepak, it only replaces first occurence

//DateTime in Javascript
// let myDate=new Date();
// console.log(myDate);   //Sun Jun 05 2022 00:39:03 GMT+0530 (India Standard Time)
// console.log(myDate.getTime());  //1654369756973  time in seconds
// console.log(myDate.getFullYear());  // 2022 full year
// console.log(myDate.getDay());  //0-> Sunday, 1-> Monday etc
// console.log(myDate.getHours()+":"+myDate.getMinutes());


//DOM Manipulation: DOM(Document Object Model)
 let element=document.getElementById('click');
// console.log(element);
 let elemClass=document.getElementsByClassName("container");
// console.log(elemClass);
// elemClass[0].style.background="yellow";
// elemClass[0].classList.add("bg-primary");
// elemClass[0].classList.add("text-success");

// console.log(element.innerHTML);
// console.log(element.innerText);


// console.log(elemClass[0].innerHTML);
// console.log(elemClass[0].innerText);

// tn=document.getElementsByTagName('div');
// console.log(tn);

// createdElement=document.createElement('p');
// createdElement.innerText="Hi, this is me dpk";
// tn[0].appendChild(createdElement);


// createdElement2=document.createElement('button');
// createdElement2.innerText="Hi, this is me another button";
// tn[0].replaceChild(createdElement2,createdElement);

//removeChild(element);  --> removes an element


// Selecting using Query
// sel=document.querySelector('.container')   //returns code inside single container class
// console.log(sel);
// sel=document.querySelectorAll('.container')   //returns code inside all container class
// console.log(sel);

//Events in Javascript
// function clicked()
// {
//     console.log("Button was clicked")   //onclick event using html
// }

// window.onload=function()
// {
//     console.log("The document got loaded");
// }


// firstContainer.addEventListener('click',function(){
//     document.querySelectorAll('.container')[1].innerHTML="<b> We have clicked </b>"
//   console.log("clicked on container");  
// });


// firstContainer.addEventListener('mouseover',function(){
//     console.log("mouse over container");  
//   });
  
  
//   firstContainer.addEventListener('mouseout',function(){
//     console.log("mouse out container");  
//   });
  
// let prevHtml=document.querySelectorAll('.container')[1].innerHTML;
//   firstContainer.addEventListener('mouseup',function(){
//     document.querySelectorAll('.container')[1].innerHTML=prevHtml;
//     console.log("mouse up when clicked on container");  
//   });

//   firstContainer.addEventListener('mousedown',function(){
//     document.querySelectorAll('.container')[1].innerHTML="<b> We have clicked </b>" 
//     console.log("mouse down when clicked on container"); 
//   });

  
// SetTimeout and SetInterval

// ArrowFunctions

// function sum(a,b)
// {
//     return a+b;
// }

// sum=(a,b)=>{
//     return a+b;
// }

// sum=()=>{
//     return 20;
// }

// logKaro=()=>{
//     document.querySelectorAll('.container')[1].innerHTML="<b> Set interval fired </b>" 
//     console.log("I am your log");
// }

//clr=setTimeout(logKaro,2000);  //toSchedule  clearTimeout(clr);  
//clr=setInterval(logKaro,2000);  //to stop this-> clearInterval(clr);  //for doing something repeatedly



//Javascript local storage
// localStorage.setItem('name','deepak');
// localStorage
// Storage {cdids: '', sb_wiz.qc: '1158', sb_wiz.zpc.n: '{"0":[],"1":{"q":"OGArU694BP_fEl9a3y4mczYUKzw","t":{"bpc":false,"tlw":false}}}', _c;;i: 'p:*|l:9007199254740991_21373', name: 'harry', …}
// localStorage.clear();
// undefined
// localStorage.setItem('name','harry');
// undefined
// localStorage.getItem
// ƒ getItem() { [native code] }
// localStorage.getItem('name');
// 'harry'


//JSON : Javascript Object Notation : Used to transport the data or exchange the data
// obj={name:"deepak", length:1,a:{
//     this:"that"             //JSON should not have single quote, it should have double quote only
// }}
// jso=JSON.stringify(obj);
// console.log(jso);
// console.log(typeof jso);
// parsed=JSON.parse(jso);
// console.log(typeof parsed);



//ECMA Script (ES) : created to standarize Javascript to maintain Javascript
//ES 10th edition: 2019


//Backticks(Template literals)
a=34;
console.log(`this is my ${a}`);  //for dollar, use backticks













































